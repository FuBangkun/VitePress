#!/usr/bin/env fish
set PREFIX "/home/fubangkun/.wine/drive_c/Program Files/miHoYoTools/zzz/"
set PROTON "/usr/share/steam/compatibilitytools.d/proton-ge-custom/"
set GAME_EXECUTABLE "/home/fubangkun/.wine/drive_c/Program Files/miHoYo Launcher/games/ZenlessZoneZero Game/ZenlessZoneZero.exe"
sudo chmod o+r /sys/class/powercap/intel-rapl\:0/energy_uj
wineserver -k
pkill -f "\.exe"
env DXVK_HUD=fps MANGOHUD=1 WINEPREFIX="$PREFIX" GAMEID="none" PROTONPATH="$PROTON" gamemoderun umu-run "$GAME_EXECUTABLE" &
